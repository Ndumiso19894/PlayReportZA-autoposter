
# PlayReportZA Autoposter (Cloudflare Worker)

This project auto-posts football halftime (HT) and full-time (FT) results
from API-Football directly to your Facebook Page using a Cloudflare Worker.

## Files
- `index.js` — main Worker script.

## Deployment Steps

1. Upload this repository to GitHub.
2. In Cloudflare → Workers & Pages → Create → Connect to GitHub.
3. Select this repo and deploy.
4. Add environment variables:

- API_FOOTBALL_KEY
- FB_PAGE_TOKEN
- FB_PAGE_ID

5. Add a Cron Trigger:
```
*/30 * * * *
```

Your autoposter will now check every 30 minutes and post results automatically.
